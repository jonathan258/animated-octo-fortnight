/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.hccis.wills.services.entity;

import info.hccis.util.CisUtility;

/**
 * @since 2022-03-18
 * @author Jonathan
 */
public class PreferredCustomer extends Customer {
    //customer since created 

    private int customerSince;

    public static final double DISCOUNT_PREFERRED = 0.10;// relocate from Customer 

    @Override
    public String getCustomerTypeDescription() {

        return " Preferred ";
    }

    @Override
    public double getDiscountRate() {
        return DISCOUNT_PREFERRED;
    }

    /**
     * Gets first name and last name 
     * Gets how long the customer is a customer 
     * 
     */
    @Override
    public void getInformation() {

        super.getInformation();
        
        customerSince = CisUtility.getInputInt("When did this person become a customer?");
    }
    
    /**
     * - Name: Joe Smith Customer Type: 
     * Preferred Customer Since: 2009
     * 
     * @return 
     */
    @Override
     public String toString() {
      String output =   super.toString() 
     + "Customer Since: " + customerSince;
  
        return output;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.hccis.wills.services.entity;

/**
 * @since 2022-03-18
 * @author Jonathan
 */
public class SeniorCustomer extends Customer {

    public static final double DISCOUNT_SENIOR = 0.15;//relocated from the Customer class 

    @Override
    public String getCustomerTypeDescription() {

        return " Senior ";
    }

    @Override

    public double getDiscountRate() {

        return DISCOUNT_SENIOR; //return the Senior discount 
    }
}
